import typingAnimation from "./typingAnimiation.js";

let thankyouMsg =
  "Thank you for contacting me. <br />I will get back to you ASAP!";
const thankyouContainer = document.querySelector("#thankyou-msg");
typingAnimation(thankyouMsg, thankyouContainer);
